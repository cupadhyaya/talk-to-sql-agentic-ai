// Renders Mermaid diagram code blocks found inside a `.prose` container
// (article / project / cheatsheet / video / bootcamp descriptions) as an
// actual diagram instead of plain text.
//
// It recognizes two shapes of markup:
//   <pre class="mermaid">graph TD; ...</pre>              <- inserted by the
//                                                             Summernote "Mermaid
//                                                             diagram" button
//   <pre><code class="language-mermaid">graph TD; ...</code></pre>  <- hand-written
//                                                             via Code View, same
//                                                             convention as the
//                                                             language-xxx classes
//                                                             highlight.js already uses
//
// Mirrors the highlight.js pass in _HomeLayout.cshtml: run once on window load,
// find the blocks, swap each one for its rendered diagram.
(function () {
    function findDiagramBlocks(container) {
        var nodes = [];
        container.querySelectorAll('pre.mermaid, pre > code.language-mermaid, pre > code.mermaid').forEach(function (el) {
            var pre = el.matches('pre') ? el : el.closest('pre');
            if (pre && nodes.indexOf(pre) === -1) {
                nodes.push(pre);
            }
        });
        return nodes;
    }

    function renderAll() {
        if (typeof mermaid === 'undefined') {
            return;
        }
        var containers = document.querySelectorAll('.prose');
        if (!containers.length) {
            return;
        }

        mermaid.initialize({
            startOnLoad: false,
            theme: document.documentElement.classList.contains('dark') ? 'dark' : 'default'
        });

        var seq = 0;
        containers.forEach(function (container) {
            findDiagramBlocks(container).forEach(function (pre) {
                // Read from the <code> element, not the <pre> itself — the copy-code
                // button script may already have injected a <button> into the <pre>,
                // and button text would corrupt pre.textContent ("Copy codeflowchart TD..."),
                // which mermaid then reports as invalid syntax.
                var codeEl = pre.querySelector('code');
                var code = (codeEl ? codeEl.textContent : pre.textContent).trim();
                var host = document.createElement('div');
                host.className = 'mermaid-diagram not-prose flex justify-center my-6';
                pre.replaceWith(host);

                var id = 'mermaid-diagram-' + Date.now() + '-' + (seq++);
                mermaid.render(id, code).then(function (result) {
                    host.innerHTML = result.svg;
                }).catch(function () {
                    host.innerHTML = '<pre class="text-xs text-red-500">Could not render this diagram — the Mermaid syntax looks invalid.</pre>';
                });
            });
        });
    }

    window.addEventListener('load', renderAll);
})();
