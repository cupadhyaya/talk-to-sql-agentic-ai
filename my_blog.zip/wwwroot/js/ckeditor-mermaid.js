// CKEditor 4 plugin: adds a "Mermaid diagram" toolbar button.
//
// Clicking it asks for Mermaid source and inserts a <pre class="mermaid"> block
// at the cursor. Like the old Summernote plugin, the diagram is shown as plain
// text while editing and rendered as a picture by the public page
// (see wwwroot/js/mermaid-render.js).
(function () {
    'use strict';
    if (typeof CKEDITOR === 'undefined') { return; }

    CKEDITOR.plugins.add('mermaid', {
        init: function (editor) {
            editor.addCommand('insertMermaid', {
                exec: function (ed) {
                    var code = window.prompt('Mermaid diagram code', 'graph TD;\n  A-->B;');
                    if (code === null || !code.trim()) { return; }

                    var pre = ed.document.createElement('pre');
                    pre.setAttribute('class', 'mermaid');
                    pre.setText(code);
                    ed.insertElement(pre);
                }
            });

            editor.ui.addButton('Mermaid', {
                label: 'Insert Mermaid diagram',
                command: 'insertMermaid',
                toolbar: 'insert,50'
            });
        }
    });
})();
