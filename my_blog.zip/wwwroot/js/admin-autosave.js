/* ---------------------------------------------------------------------------
   Autosave — admin & student forms
   Any form marked with data-autosave="<key>" is snapshotted every few seconds
   and stored under the signed-in user via /FormDraft (see FormDraftController).
   It never writes to the real content tables, so a half-written article can
   never leak onto the public site.
   When the same form is reopened and the stored snapshot differs from what the
   page currently shows, a small banner offers the unsaved work back.
   --------------------------------------------------------------------------- */
(function () {
    'use strict';
    if (!window.fetch || !window.URLSearchParams) { return; }

    var POLL_MS = 4000;
    var SAVE_URL = '/FormDraft/Save';
    var GET_URL = '/FormDraft/Get';
    var CLEAR_URL = '/FormDraft/Clear';

    var form = document.querySelector('form[data-autosave]');
    if (!form) { return; }

    var formKey = form.getAttribute('data-autosave');
    var tokenEl = document.querySelector('#afToken input[name="__RequestVerificationToken"]');
    if (!formKey || !tokenEl) { return; }
    var token = tokenEl.value;

    // ---- capture -----------------------------------------------------------

    function skipped(el) {
        var name = el.name;
        if (!name || name === '__RequestVerificationToken' || name.charAt(0) === '_') { return true; }
        var type = (el.type || '').toLowerCase();
        return type === 'file' || type === 'submit' || type === 'button' ||
               type === 'reset' || type === 'password';
    }

    function isSummernote(el) {
        return el.tagName === 'TEXTAREA' && !!window.jQuery &&
               jQuery(el).next('.note-editor').length > 0;
    }

    function ckEditorInstance(el) {
        return (el.tagName === 'TEXTAREA' && window.CKEDITOR && CKEDITOR.instances)
            ? CKEDITOR.instances[el.id]
            : null;
    }

    function snapshot() {
        var values = {}, checks = {};
        Array.prototype.forEach.call(form.elements, function (el) {
            if (skipped(el)) { return; }
            var type = (el.type || '').toLowerCase();
            if (type === 'checkbox') { checks[el.name] = !!el.checked; return; }
            if (type === 'radio') {
                if (el.checked) { checks[el.name] = el.value; }
                else if (!(el.name in checks)) { checks[el.name] = null; }
                return;
            }
            if (el.disabled) { return; }
            var value = el.value;
            var ck = ckEditorInstance(el);
            if (ck) {
                try { value = ck.getData(); } catch (e) {}
            } else if (isSummernote(el)) {
                try { value = jQuery(el).summernote('code'); } catch (e) {}
            }
            values[el.name] = value;
        });
        return JSON.stringify({ values: values, checks: checks });
    }

    function requestBody(key, payload) {
        var p = new URLSearchParams();
        p.set('__RequestVerificationToken', token);
        p.set('key', key);
        if (typeof payload === 'string') { p.set('payload', payload); }
        return p;
    }

    function clearDraft(key) {
        try {
            fetch(CLEAR_URL, { method: 'POST', body: requestBody(key), credentials: 'same-origin' })
                .catch(function () {});
        } catch (e) {}
    }

    // ---- little status pill (bottom-right, above the sticky save bar) ------

    var pill = document.createElement('div');
    pill.setAttribute('style',
        'position:fixed;right:16px;bottom:90px;z-index:50;background:rgba(15,23,42,.92);' +
        'color:#fff;padding:7px 13px;border-radius:11px;font-size:11px;font-weight:600;' +
        'line-height:1.2;font-family:inherit;box-shadow:0 8px 24px rgba(15,23,42,.25);');
    pill.textContent = '⏱ Autosave on';
    document.body.appendChild(pill);

    function clock() {
        return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }

    // ---- saving ------------------------------------------------------------

    var baseline = snapshot();   // what the page showed when it opened
    var lastSaved = baseline;    // the last state we know matches the stored draft
    var userTouched = false;     // only save after the person actually edits something

    ['input', 'change', 'keydown', 'paste', 'cut', 'drop'].forEach(function (evt) {
        form.addEventListener(evt, function () { userTouched = true; }, true);
    });

    // CKEditor edits happen inside an iframe, so the form-level listeners above
    // never see them. Listen on the editor instance as well.
    function bindCKEditors() {
        Array.prototype.forEach.call(form.elements, function (el) {
            var ck = ckEditorInstance(el);
            if (ck && ck.on && !ck.__autosaveBound) {
                ck.__autosaveBound = true;
                ck.on('change', function () { userTouched = true; });
            }
        });
    }
    bindCKEditors();

    function saveNow(viaBeacon) {
        if (!userTouched) { return; }
        var snap = snapshot();
        if (snap === lastSaved) { return; }

        if (viaBeacon) {
            // Tab is closing / navigating away — fire and forget; sendBeacon survives unload.
            try {
                if (navigator.sendBeacon && navigator.sendBeacon(SAVE_URL, requestBody(formKey, snap))) {
                    lastSaved = snap;
                    return;
                }
            } catch (e) {}
            try {
                fetch(SAVE_URL, { method: 'POST', body: requestBody(formKey, snap), credentials: 'same-origin', keepalive: true });
                lastSaved = snap;
            } catch (e) {}
            return;
        }

        pill.textContent = '⏳ Autosaving…';
        fetch(SAVE_URL, { method: 'POST', body: requestBody(formKey, snap), credentials: 'same-origin' })
            .then(function (r) {
                if (!r.ok) { throw new Error('HTTP ' + r.status); }
                lastSaved = snap;
                pill.textContent = '✓ Autosaved ' + clock();
            })
            .catch(function () { pill.textContent = '⚠ Autosave failed — retrying'; });
    }

    setInterval(function () {
        bindCKEditors(); // handles editors that finish loading after this script runs
        // Until the person edits something, keep following whatever the page itself
        // changed (async lists, previews, …) so it can never look "dirty" by itself.
        if (!userTouched) { lastSaved = snapshot(); return; }
        saveNow(false);
    }, POLL_MS);

    window.addEventListener('beforeunload', function () { saveNow(true); });
    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'hidden') { saveNow(true); }
    });

    // ---- restore work left behind by an earlier visit ----------------------

    function applyPayload(values, checks) {
        Array.prototype.forEach.call(form.elements, function (el) {
            if (skipped(el)) { return; }
            var type = (el.type || '').toLowerCase();
            if (type === 'checkbox') {
                el.checked = !!checks[el.name];
                el.dispatchEvent(new Event('change', { bubbles: true }));
                return;
            }
            if (type === 'radio') {
                el.checked = (checks[el.name] === el.value);
                return;
            }
            if (!(el.name in values)) { return; }
            var value = values[el.name];
            var ck = ckEditorInstance(el);
            if (ck) {
                try { ck.setData(value); } catch (e) {}
                el.value = value;
            } else if (isSummernote(el)) {
                try { jQuery(el).summernote('code', value); } catch (e) { el.value = value; }
            } else {
                el.value = value;
            }
            el.dispatchEvent(new Event('change', { bubbles: true }));
        });
    }

    function showRestoreBar(payloadJson, savedAt) {
        var when = savedAt ? new Date(savedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';

        var bar = document.createElement('div');
        bar.className = 'mb-5 flex flex-wrap items-center gap-3 rounded-2xl border-2 border-indigo-200 ' +
            'bg-indigo-50 px-4 py-3 text-sm dark:border-indigo-800 dark:bg-indigo-950/40';

        var text = document.createElement('span');
        text.className = 'font-semibold text-indigo-900 dark:text-indigo-200';
        text.textContent = '📝 Unsaved changes found' + (when ? ' from ' + when : '') + ' — this form was not saved last time.';

        var restoreBtn = document.createElement('button');
        restoreBtn.type = 'button';
        restoreBtn.className = 'ml-auto rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-indigo-700';
        restoreBtn.textContent = 'Restore them';
        restoreBtn.addEventListener('click', function () {
            try {
                var data = JSON.parse(payloadJson) || {};
                applyPayload(data.values || {}, data.checks || {});
                lastSaved = snapshot();
            } catch (e) {}
            bar.remove();
            pill.textContent = '✓ Restored — autosave on';
        });

        var discardBtn = document.createElement('button');
        discardBtn.type = 'button';
        discardBtn.className = 'rounded-xl border border-indigo-200 bg-white px-3.5 py-2 text-xs font-bold text-indigo-700 hover:bg-indigo-100 dark:border-indigo-800 dark:bg-slate-900 dark:text-indigo-300';
        discardBtn.textContent = 'Discard';
        discardBtn.addEventListener('click', function () {
            clearDraft(formKey);
            bar.remove();
            pill.textContent = '⏱ Autosave on';
        });

        bar.appendChild(text);
        bar.appendChild(restoreBtn);
        bar.appendChild(discardBtn);

        var host = document.getElementById('dashboard') || document.querySelector('main') || document.body;
        host.insertBefore(bar, host.firstChild);
    }

    // A page that came back with validation errors was never saved — its values are
    // on screen already, so there is nothing to restore (and nothing to tidy up).
    var validationFailed = !!document.querySelector('.validation-summary-errors, .input-validation-error');

    fetch(GET_URL + '?key=' + encodeURIComponent(formKey), { credentials: 'same-origin' })
        .then(function (r) { return (r.ok && r.status !== 204) ? r.json() : null; })
        .then(function (d) {
            if (!d || !d.payload) { return; }
            if (d.payload === baseline) {
                // The stored snapshot matches what is already on the page — nothing to rescue.
                if (!validationFailed) { clearDraft(formKey); }
                return;
            }
            if (!validationFailed) { showRestoreBar(d.payload, d.savedAt); }
        })
        .catch(function () {});
})();
