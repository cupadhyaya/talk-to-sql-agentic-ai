/*
 * Shared image picker: instant preview + client-side crop for photo uploads.
 *
 * Add `data-image-crop` to any <input type="file" accept="image/*"> to enable.
 * Optional attributes:
 *   data-crop-aspect="1"        – width / height of the crop (default 1, square)
 *   data-crop-preview="imgId"   – id of an <img> updated with the preview
 *   data-crop-max="900"         – longest edge of the exported JPEG
 *
 * The chosen file is replaced in the input with the cropped JPEG (via
 * DataTransfer), so every existing server-side upload path keeps working.
 */
(function () {
    'use strict';

    function ready(fn) {
        if (document.readyState !== 'loading') fn();
        else document.addEventListener('DOMContentLoaded', fn);
    }

    var CSS = '' +
        '.icrop-backdrop{position:fixed;inset:0;z-index:2147483000;display:none;align-items:center;justify-content:center;padding:18px;background:rgba(10,15,30,.62);backdrop-filter:blur(3px)}' +
        '.icrop-backdrop.is-open{display:flex}' +
        '.icrop-panel{display:flex;flex-direction:column;width:min(94vw,540px);max-height:96vh;overflow:auto;background:#fff;border-radius:18px;box-shadow:0 30px 80px -20px rgba(8,15,40,.55);font-family:inherit}' +
        '.icrop-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 20px 0}' +
        '.icrop-head h3{margin:0;font-size:16px;font-weight:800;color:#111a33;letter-spacing:-.01em}' +
        '.icrop-head p{margin:3px 0 0;font-size:12px;color:#64748b}' +
        '.icrop-close{border:0;background:#f1f4fa;color:#475569;width:32px;height:32px;border-radius:10px;font-size:18px;cursor:pointer;line-height:1}' +
        '.icrop-stage{margin:14px auto 0;position:relative;overflow:hidden;border-radius:14px;background:#0f172a;touch-action:none;cursor:grab}' +
        '.icrop-stage:active{cursor:grabbing}' +
        '.icrop-stage canvas{display:block;width:100%;height:100%}' +
        '.icrop-ring{position:absolute;inset:0;border-radius:14px;box-shadow:inset 0 0 0 2px rgba(255,255,255,.7),inset 0 0 60px 24px rgba(6,10,24,.24);pointer-events:none}' +
        '.icrop-zoom{display:flex;align-items:center;gap:10px;padding:12px 20px 0;font-size:12px;font-weight:700;color:#64748b}' +
        '.icrop-zoom input{flex:1;accent-color:#5646f0}' +
        '.icrop-actions{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:9px;padding:16px 20px 20px}' +
        '.icrop-btn{border:1px solid #dfe4ef;background:#fff;color:#334155;border-radius:11px;padding:9px 16px;font-size:13px;font-weight:750;cursor:pointer}' +
        '.icrop-btn:hover{border-color:#c4c9ff;background:#f8f9ff}' +
        '.icrop-btn-primary{border-color:transparent;background:linear-gradient(100deg,#5646f0,#7a4cf0);color:#fff;box-shadow:0 10px 22px -12px rgba(86,70,240,.9)}' +
        '.icrop-btn-primary:hover{filter:brightness(1.05);background:linear-gradient(100deg,#5646f0,#7a4cf0)}' +
        '.icrop-thumb{width:56px;height:56px;border-radius:50%;object-fit:cover;box-shadow:0 0 0 2px #fff,0 6px 16px -8px rgba(17,26,51,.5);flex-shrink:0}' +
        '@media(max-width:520px){.icrop-stage{border-radius:12px}.icrop-actions{padding:14px 16px 18px}}';

    function injectCss() {
        if (document.getElementById('icrop-css')) return;
        var style = document.createElement('style');
        style.id = 'icrop-css';
        style.textContent = CSS;
        document.head.appendChild(style);
    }

    function parseAspect(value) {
        if (!value) return 1;
        var parts = String(value).split(/[\/:x]/);
        var a = parseFloat(parts[0]);
        var b = parts.length > 1 ? parseFloat(parts[1]) : 1;
        if (!a || !b) return 1;
        return a / b;
    }

    function formatBytes(bytes) {
        if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + ' KB';
        return (bytes / 1024 / 1024).toFixed(1) + ' MB';
    }

    function openCropper(options) {
        injectCss();
        var aspect = options.aspect;
        var maxEdge = options.maxEdge;

        var backdrop = document.createElement('div');
        backdrop.className = 'icrop-backdrop is-open';
        backdrop.innerHTML =
            '<div class="icrop-panel" role="dialog" aria-modal="true" aria-label="Crop photo">' +
                '<div class="icrop-head">' +
                    '<div><h3>Crop your photo</h3><p>Drag to position · zoom to fit the circle</p></div>' +
                    '<button type="button" class="icrop-close" aria-label="Close">×</button>' +
                '</div>' +
                '<div class="icrop-stage" style="width:min(86vw,480px);aspect-ratio:' + aspect + '">' +
                    '<canvas></canvas><span class="icrop-ring"></span>' +
                '</div>' +
                '<label class="icrop-zoom">Zoom' +
                    '<input type="range" min="1" max="4" step="0.01" value="1" />' +
                '</label>' +
                '<div class="icrop-actions">' +
                    '<button type="button" class="icrop-btn" data-icrop-cancel>Cancel</button>' +
                    '<button type="button" class="icrop-btn" data-icrop-original>Keep original</button>' +
                    '<button type="button" class="icrop-btn icrop-btn-primary" data-icrop-save>Use cropped photo</button>' +
                '</div>' +
            '</div>';
        document.body.appendChild(backdrop);

        var stage = backdrop.querySelector('.icrop-stage');
        var canvas = backdrop.querySelector('canvas');
        var zoomInput = backdrop.querySelector('input[type=range]');
        var ctx = canvas.getContext('2d');
        var img = options.image;
        var state = { zoom: 1, x: 0, y: 0, dragging: false, startX: 0, startY: 0, originX: 0, originY: 0 };

        // Internal canvas resolution: longest edge 900px (enough for retina avatars).
        var stageRect = stage.getBoundingClientRect();
        var cssW = stageRect.width || 480;
        var cssH = cssW / aspect;
        var dpr = Math.min(window.devicePixelRatio || 1, 2);
        canvas.width = Math.round(cssW * dpr);
        canvas.height = Math.round(cssH * dpr);
        ctx.scale(dpr, dpr);

        function coverScale() { return Math.max(cssW / img.width, cssH / img.height); }
        function draw() {
            var scale = coverScale() * state.zoom;
            var drawnW = img.width * scale;
            var drawnH = img.height * scale;
            var maxX = Math.max(0, (drawnW - cssW) / 2);
            var maxY = Math.max(0, (drawnH - cssH) / 2);
            state.x = Math.max(-maxX, Math.min(maxX, state.x));
            state.y = Math.max(-maxY, Math.min(maxY, state.y));
            ctx.clearRect(0, 0, cssW, cssH);
            ctx.save();
            ctx.translate(cssW / 2 + state.x, cssH / 2 + state.y);
            ctx.scale(scale, scale);
            ctx.drawImage(img, -img.width / 2, -img.height / 2);
            ctx.restore();
        }
        draw();

        function close() {
            backdrop.remove();
            document.removeEventListener('keydown', onKey);
            if (options.onClose) options.onClose();
        }
        function onKey(e) { if (e.key === 'Escape') close(); }

        backdrop.addEventListener('click', function (e) { if (e.target === backdrop) close(); });
        backdrop.querySelector('.icrop-close').addEventListener('click', close);
        backdrop.querySelector('[data-icrop-cancel]').addEventListener('click', close);
        document.addEventListener('keydown', onKey);

        zoomInput.addEventListener('input', function () {
            state.zoom = parseFloat(zoomInput.value);
            draw();
        });

        canvas.addEventListener('pointerdown', function (e) {
            state.dragging = true;
            state.startX = e.clientX; state.startY = e.clientY;
            state.originX = state.x; state.originY = state.y;
            canvas.setPointerCapture(e.pointerId);
        });
        canvas.addEventListener('pointermove', function (e) {
            if (!state.dragging) return;
            state.x = state.originX + (e.clientX - state.startX);
            state.y = state.originY + (e.clientY - state.startY);
            draw();
        });
        canvas.addEventListener('pointerup', function (e) {
            state.dragging = false;
            try { canvas.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        });
        canvas.addEventListener('pointercancel', function () { state.dragging = false; });
        canvas.addEventListener('wheel', function (e) {
            e.preventDefault();
            state.zoom = Math.max(1, Math.min(4, state.zoom * (e.deltaY > 0 ? 0.94 : 1.06)));
            zoomInput.value = String(state.zoom);
            draw();
        }, { passive: false });

        backdrop.querySelector('[data-icrop-original]').addEventListener('click', function () {
            close();
            if (options.onOriginal) options.onOriginal();
        });
        backdrop.querySelector('[data-icrop-save]').addEventListener('click', function () {
            var scale = coverScale() * state.zoom;
            var outW = Math.round(img.width * scale);
            var outH = Math.round(img.height * scale);
            var cropX = Math.round(img.width / 2 - (cssW / 2 + state.x) / scale);
            var cropY = Math.round(img.height / 2 - (cssH / 2 + state.y) / scale);
            var cropW = Math.round(cssW / scale);
            var cropH = Math.round(cssH / scale);
            // Clamp the crop rectangle inside the image.
            cropX = Math.max(0, Math.min(img.width - cropW, cropX));
            cropY = Math.max(0, Math.min(img.height - cropH, cropY));

            var longest = Math.min(maxEdge, Math.max(cropW, cropH));
            var ratio = longest / Math.max(cropW, cropH);
            var finalW = Math.max(1, Math.round(cropW * ratio));
            var finalH = Math.max(1, Math.round(cropH * ratio));

            var out = document.createElement('canvas');
            out.width = finalW;
            out.height = finalH;
            out.getContext('2d').drawImage(img, cropX, cropY, cropW, cropH, 0, 0, finalW, finalH);
            out.toBlob(function (blob) {
                close();
                if (!blob) { if (options.onOriginal) options.onOriginal(); return; }
                if (options.onCropped) options.onCropped(blob, finalW, finalH);
            }, 'image/jpeg', 0.92);
        });
    }

    function attach(input) {
        var previewId = input.getAttribute('data-crop-preview');
        var previewImg = previewId ? document.getElementById(previewId) : null;

        // If no preview target exists, create one just before the input.
        if (!previewImg) {
            previewImg = document.createElement('img');
            previewImg.className = 'icrop-thumb';
            previewImg.alt = 'Photo preview';
            previewImg.hidden = true;
            input.parentNode.insertBefore(previewImg, input);
        }

        var lastUrl = null;
        function showPreview(blobOrUrl) {
            if (lastUrl) URL.revokeObjectURL(lastUrl);
            var url = typeof blobOrUrl === 'string' ? blobOrUrl : URL.createObjectURL(blobOrUrl);
            lastUrl = typeof blobOrUrl === 'string' ? null : url;
            previewImg.src = url;
            previewImg.hidden = false;
            var initial = document.getElementById(previewImg.id + 'Initial');
            if (initial) initial.hidden = true;
        }

        input.addEventListener('change', function () {
            if (input.getAttribute('data-icrop-skip') === '1') return;
            var file = input.files && input.files[0];
            if (!file) return;
            if (!/^image\//.test(file.type)) {
                alert('Please choose an image file (JPG, PNG or WebP).');
                input.value = '';
                return;
            }

            var url = URL.createObjectURL(file);
            var image = new Image();
            image.onload = function () {
                openCropper({
                    image: image,
                    aspect: parseAspect(input.getAttribute('data-crop-aspect')),
                    maxEdge: parseInt(input.getAttribute('data-crop-max'), 10) || 900,
                    onOriginal: function () {
                        showPreview(file);
                    },
                    onCropped: function (blob) {
                        showPreview(blob);
                        var name = (file.name || 'photo').replace(/\.[^.]+$/, '') + '-cropped.jpg';
                        var cropped = new File([blob], name, { type: 'image/jpeg', lastModified: Date.now() });
                        try {
                            var dt = new DataTransfer();
                            dt.items.add(cropped);
                            input.files = dt.files;
                            // Let other page scripts (live previews, file labels)
                            // refresh with the cropped file without reopening us.
                            input.setAttribute('data-icrop-skip', '1');
                            input.dispatchEvent(new Event('change', { bubbles: true }));
                            input.removeAttribute('data-icrop-skip');
                        } catch (err) {
                            // Older browsers: fall back to the original file.
                        }
                    },
                    onClose: function () {
                        URL.revokeObjectURL(url);
                    }
                });
            };
            image.onerror = function () {
                URL.revokeObjectURL(url);
                alert('That image could not be read. Please try another file.');
                input.value = '';
            };
            image.src = url;
        });
    }

    ready(function () {
        document.querySelectorAll('input[type=file][data-image-crop]').forEach(attach);
    });

    // Allow dynamic forms to opt in later.
    window.initImageCrop = function (root) {
        (root || document).querySelectorAll('input[type=file][data-image-crop]').forEach(attach);
    };
})();
