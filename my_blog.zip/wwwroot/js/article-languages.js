/* Repeater for the article "also available in other languages" rows.
   Each row is just two fields (language + link); the index in the input names is
   renumbered after every add/remove so ASP.NET model binding always sees 0..n-1. */
(function () {
    'use strict';

    function init(root) {
        var rows = root.querySelector('[data-language-rows]');
        var template = root.querySelector('[data-language-template]');
        var add = root.querySelector('[data-add-language]');
        if (!rows || !template || !add) { return; }

        function reindex() {
            Array.prototype.forEach.call(rows.querySelectorAll('[data-language-row]'), function (row, index) {
                Array.prototype.forEach.call(row.querySelectorAll('[name]'), function (input) {
                    input.name = input.name.replace(/Translations\[[^\]]*\]/, 'Translations[' + index + ']');
                });
            });
        }

        add.addEventListener('click', function () {
            var next = rows.querySelectorAll('[data-language-row]').length;
            var wrapper = document.createElement('div');
            wrapper.innerHTML = template.innerHTML.replace(/__index__/g, next).trim();
            var row = wrapper.firstElementChild;
            if (!row) { return; }
            rows.appendChild(row);
            reindex();
            var first = row.querySelector('input');
            if (first) { first.focus(); }
        });

        rows.addEventListener('click', function (event) {
            var button = event.target.closest('[data-remove-language]');
            if (!button) { return; }
            var row = button.closest('[data-language-row]');
            if (row) { row.remove(); }
            reindex();
        });

        reindex();
    }

    document.querySelectorAll('[data-language-repeater]').forEach(init);
})();
